import { createHash } from "node:crypto";

export const GENESIS_TIMESTAMP = "2026-01-01T00:00:00.000Z";
const ZERO_HASH = "0".repeat(64);

export function sha256(value) {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

export function calculateBlockHash(block) {
  const payload = JSON.stringify({
    index: block.index,
    timestamp: block.timestamp,
    transactions: block.transactions,
    previousHash: block.previousHash,
    nonce: block.nonce
  });
  return sha256(payload);
}

export function createBlock({ index, transactions, previousHash, timestamp = new Date().toISOString(), nonce = 0 }) {
  if (!Number.isInteger(index) || index < 0) throw new TypeError("index must be a non-negative integer");
  if (!Array.isArray(transactions)) throw new TypeError("transactions must be an array");
  if (typeof previousHash !== "string" || previousHash.length !== 64) throw new TypeError("previousHash must be a 64-character hash");
  if (!Number.isInteger(nonce) || nonce < 0) throw new TypeError("nonce must be a non-negative integer");
  const block = { index, timestamp, transactions, previousHash, nonce };
  return { ...block, hash: calculateBlockHash(block) };
}

export function createGenesisBlock() {
  return createBlock({ index: 0, timestamp: GENESIS_TIMESTAMP, transactions: [], previousHash: ZERO_HASH, nonce: 0 });
}

export class NoryxChain {
  constructor() { this.chain = [createGenesisBlock()]; }
  getLatestBlock() { return this.chain[this.chain.length - 1]; }

  addBlock(transactions, timestamp = new Date().toISOString()) {
    const block = createBlock({
      index: this.chain.length,
      timestamp,
      transactions,
      previousHash: this.getLatestBlock().hash
    });
    this.chain.push(block);
    return block;
  }

  isValid() {
    if (!Array.isArray(this.chain) || this.chain.length === 0) return false;
    const genesis = this.chain[0];
    if (genesis.index !== 0 || genesis.timestamp !== GENESIS_TIMESTAMP ||
        genesis.previousHash !== ZERO_HASH || !Array.isArray(genesis.transactions) ||
        genesis.hash !== calculateBlockHash(genesis)) return false;
    for (let i = 1; i < this.chain.length; i++) {
      const current = this.chain[i];
      const previous = this.chain[i - 1];
      if (current.index !== i || current.previousHash !== previous.hash ||
          !Array.isArray(current.transactions) || current.hash !== calculateBlockHash(current)) return false;
    }
    return true;
  }

  toJSON() { return this.chain; }
}
