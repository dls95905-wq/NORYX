import { NoryxChain } from "./blockchain.js";

const chain = new NoryxChain();
chain.addBlock(
  [{ type: "MESSAGE", from: "noryx-demo", data: "NORYX Layer-1 is starting" }],
  "2026-01-01T00:01:00.000Z"
);

console.log("NORYX Layer-1 local prototype");
console.log(JSON.stringify({
  blockCount: chain.chain.length,
  chainIsValid: chain.isValid(),
  latestBlock: chain.getLatestBlock()
}, null, 2));
