# NORYX Layer-1 — v0.1

This ZIP contains the first local prototype of the NORYX blockchain core.

## Included
- SHA-256 block hashing
- Deterministic genesis block
- Sequential block creation
- Previous-block hash linking
- Basic chain-integrity validation
- Automated tests using Node.js built-in test runner
- No third-party package dependencies

## Requirements
Node.js 20 or newer.

## Run
```bash
npm test
npm start
```

## Limitations
This is an early, single-process development prototype, not a production or decentralized blockchain. It does not yet include peer-to-peer networking, consensus, signed wallet transactions, a transaction pool, smart contracts, persistent storage, or a security review. Do not use it to hold or transfer real funds.

## Roadmap
1. Block and chain validation
2. Wallet keys and signed transactions
3. Transaction validation and mempool
4. Consensus protocol
5. Peer-to-peer node networking
6. RPC/API and developer tooling
7. Security review and testnet
