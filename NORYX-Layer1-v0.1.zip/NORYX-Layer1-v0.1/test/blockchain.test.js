import test from "node:test";
import assert from "node:assert/strict";
import { NoryxChain, createGenesisBlock, calculateBlockHash } from "../src/blockchain.js";

test("genesis block has index zero and a valid hash", () => {
  const genesis = createGenesisBlock();
  assert.equal(genesis.index, 0);
  assert.equal(genesis.previousHash, "0".repeat(64));
  assert.equal(genesis.hash, calculateBlockHash(genesis));
});

test("new block links to the previous block", () => {
  const chain = new NoryxChain();
  const block = chain.addBlock([{ type: "MESSAGE", data: "hello" }], "2026-01-01T00:01:00.000Z");
  assert.equal(block.index, 1);
  assert.equal(block.previousHash, chain.chain[0].hash);
  assert.equal(chain.isValid(), true);
});

test("tampering with a block is detected", () => {
  const chain = new NoryxChain();
  chain.addBlock([{ type: "MESSAGE", data: "hello" }], "2026-01-01T00:01:00.000Z");
  chain.chain[1].transactions[0].data = "tampered";
  assert.equal(chain.isValid(), false);
});

test("non-array transactions are rejected", () => {
  const chain = new NoryxChain();
  assert.throws(() => chain.addBlock("not-an-array"), /transactions must be an array/);
});
