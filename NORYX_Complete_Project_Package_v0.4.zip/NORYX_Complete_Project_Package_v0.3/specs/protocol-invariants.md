# NORYX Protocol Invariants

This document is the source of truth for protocol-level acceptance tests.

## Monetary units
- Denomination: pending final naming decision (do not guess in genesis)
- Display symbol: NORYX
- Decimals: 6
- Maximum whole-token supply: 100,000,000
- Maximum base units: 100,000,000,000,000

## Supply invariants
- `total_supply <= 100000000000000` at genesis and after every committed block.
- Runtime minting must be unavailable to ordinary messages, governance proposals, module accounts, and reward distribution.
- Genesis allocations must be non-negative and their sum must not exceed the cap.
- If the final economic decision is that all coins exist at genesis, the allocation sum must equal the cap exactly.

## Fee and staking reward invariants
- Only successfully collected fees can enter the reward pool.
- A failed or reverted transaction cannot contribute fees to the reward pool unless the final transaction-fee policy explicitly charges failed transactions and the fee is actually committed.
- Sum of validator rewards for an epoch/block must be less than or equal to the fee pool allocated for that same period.
- No fixed APR or target reward is guaranteed; zero collected fees means zero fee-funded rewards.
- Rounding remainder handling must be deterministic across all validators.

## Consensus and state invariants
- All validators must execute the same deterministic state transition for the same ordered transactions.
- Duplicate transactions, invalid signatures, stale sequence numbers, and replayed messages must be rejected.
- Validator-set updates, slashing, unbonding, and reward accounting must be deterministic and atomic.

## Launch gates
A testnet/mainnet genesis cannot be finalized until chain ID, address prefix, base denomination, allocations, validator set, staking parameters, fee policy, block parameters, governance parameters, and genesis timestamp are explicitly approved and tested.
