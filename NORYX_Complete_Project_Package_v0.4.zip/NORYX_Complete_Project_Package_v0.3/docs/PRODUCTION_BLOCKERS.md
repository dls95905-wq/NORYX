# Production blockers and launch gates

NORYX must not be described as mainnet-ready until every gate below is evidenced.

## Gate 1 — Protocol decisions

The following are still undecided and must be approved before a real genesis can be generated:

- Chain ID and network naming convention
- Address prefix and account/validator address formats
- Base denomination (recommended naming candidate: `unoryx`, subject to approval)
- Genesis timestamp and chain version
- Initial allocations and vesting schedules, if any
- Initial validator set and validator public keys
- Minimum self-delegation / minimum stake
- Unbonding duration and redelegation restrictions
- Validator commission bounds and change interval
- Transaction fee policy and fee denomination
- Exact fee distribution split between validators/delegators/community or burn
- Block parameters, evidence parameters and governance parameters
- Upgrade authority and emergency response policy

Do not fill these with invented values. Genesis allocations must sum to no more than 100,000,000 NORYX and must be reconciled with the fixed supply invariant.

## Gate 2 — Integrated application

- Pin an officially compatible Cosmos SDK / CometBFT release family and exact patch versions.
- Wire auth, bank, staking, slashing, distribution, governance, upgrade and required core modules.
- Disable all inflationary mint paths and prove no module can mint after genesis.
- Route actual collected fees into the fee-only reward mechanism; failed transactions must not pay rewards.
- Ensure transaction execution, fee collection and reward distribution are atomic and deterministic.
- Add invariants, simulation tests, property tests, fuzz tests and upgrade tests.

## Gate 3 — Operational network

- Build reproducible node binaries and genesis tooling.
- Run at least four independently operated validators in a public testnet.
- Test validator downtime, double-sign evidence, node restart, state sync, snapshot restore and network partitions.
- Publish RPC/API limits, monitoring, alerting, backups and incident procedures.
- Verify validator keys are generated and stored securely by each operator.

## Gate 4 — Release safety

- Independent security audit and remediation.
- Reproducible builds, checksums, signed releases and rollback/upgrade runbooks.
- Public testnet soak period and documented bug bounty / disclosure channel.
- Genesis ceremony with independently verified allocations and validator keys.
- Explicit go/no-go approval by the project owner and validator operators.

## Infrastructure reality

A public decentralized chain requires always-on machines operated by multiple independent parties. A single phone or a ZIP archive cannot provide distributed validator uptime. Free-tier services may sleep, impose quotas, or be unsuitable for consensus-critical nodes.
