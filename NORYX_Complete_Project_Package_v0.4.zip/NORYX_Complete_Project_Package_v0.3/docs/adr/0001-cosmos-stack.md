# ADR 0001: Cosmos SDK + CometBFT

- Status: Accepted as the project architecture baseline
- Date: 2026-11-09

## Decision
Build NORYX as an independent Cosmos SDK application using the compatible Cosmos SDK 0.55.x / CometBFT 0.40.x release family. Pin exact patch versions only after the full dependency graph and toolchain are verified in CI.

## Rationale
The official 2026.1 Cosmos release family pairs Cosmos SDK 0.55.x with CometBFT 0.40.x. Cosmos SDK 0.55 requires CometBFT 0.40.0. The project must use a tested compatible family rather than independently selecting arbitrary versions.

## Non-negotiable NORYX protocol invariants
1. Maximum supply is 100,000,000 NORYX.
2. Decimal precision is 6; maximum base units are 100,000,000,000,000.
3. Runtime inflation is disabled.
4. Staking rewards are funded only by transaction fees actually collected by the chain.
5. Reward distribution cannot exceed the collected fee pool and must be deterministic and atomic.
6. No genesis allocations, chain ID, address prefix, denomination, validator keys, or launch time may be invented; these remain explicit launch decisions.

## Consequences
- The application must customize or disable every default mint/inflation path that could violate the cap.
- Fee collection and distribution must be implemented as consensus state transitions, not merely helper functions.
- Staking, slashing, governance, upgrades, RPC, and node operations require integration and multi-validator testing.
- This decision does not mean the NORYX application has already been implemented or is mainnet-ready.
