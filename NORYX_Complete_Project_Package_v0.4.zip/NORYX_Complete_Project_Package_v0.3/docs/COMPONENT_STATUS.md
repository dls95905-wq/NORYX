# NORYX component status — v0.3

Legend: **Implemented helper** means a limited library or document exists; it does not mean the production subsystem is complete.

| Component | Status | Evidence / next work |
|---|---|---|
| Fixed-supply arithmetic | Implemented helper | `protocol/supply`; integrate as consensus state invariant and test genesis/import/upgrade paths |
| Fee-only reward arithmetic | Implemented helper | `protocol/fees`; integrate atomically with fee collection and distribution modules |
| Block hash data model | Prototype only | `protocol/chain`; replace with SDK state machine + CometBFT consensus |
| Cosmos SDK application | Not implemented | App wiring, module accounts, stores, CLI, config, migrations |
| CometBFT node integration | Not implemented | Compatible release family, ABCI app, node config and multi-node operation |
| PoS validator lifecycle | Not implemented | Create/edit/unbond/delegate/redelegate, power updates, commission |
| Slashing/evidence | Not implemented | Downtime/double-sign handling, evidence windows, safety tests |
| Bank and signed transactions | Not implemented | Account sequence, signatures, fee checks, replay protection, atomic execution |
| Mempool and block execution | Not implemented | SDK transaction pipeline and deterministic state transitions |
| P2P / state sync | Not implemented | Peer discovery, snapshots, state sync, network hardening |
| Persistent storage | Not implemented | Database configuration, pruning, backups, crash recovery |
| RPC / REST / gRPC | Not implemented | Authenticated/limited public endpoints and API compatibility tests |
| Wallet | Not implemented | Key generation/storage, signing, send/receive, recovery UX; security review |
| Explorer / indexer | Not implemented | Block/tx/address indexing, pagination, reorg-safe ingestion |
| Governance | Not implemented | Proposal lifecycle, voting, deposits, parameter changes, upgrade proposals |
| Testnet | Not deployed | Multi-operator validators, faucet policy, monitoring, incident drills |
| Mainnet | Not launched | Genesis ceremony, independent audit, operators, infrastructure, release sign-off |

## Completion rule

A row is complete only after code is integrated into the running application, automated tests cover its failure modes, and the resulting binary/network is exercised in a multi-validator environment. A design document or stub does not count as implementation.
