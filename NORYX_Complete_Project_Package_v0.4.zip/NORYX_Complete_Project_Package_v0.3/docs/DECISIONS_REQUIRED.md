# Decisions required before a real genesis

These values are intentionally not guessed. A production genesis cannot be finalized until they are approved and independently checked.

- Chain ID and network naming policy
- Bech32 address prefix and base denomination
- Genesis timestamp and coordinated launch procedure
- Initial account allocations and allocation proofs; total must not exceed 100,000,000 NORYX
- Initial validator identities and validator power distribution
- Minimum self-delegation, minimum delegation, unbonding duration, redelegation rules
- Slashing rates, downtime windows, evidence age limits
- Transaction fee denomination, minimum gas price, fee split and validator commission policy
- Block timing, block gas limit, evidence parameters
- Governance quorum, threshold, veto threshold, voting period and deposit rules
- Upgrade authority, software release policy and emergency response procedure

Do not publish private keys, validator signing keys, seed phrases, or recovery phrases in genesis files or a public repository.
