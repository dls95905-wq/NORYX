# NORYX verification matrix

| Area | Required tests before testnet |
|---|---|
| Supply | Genesis sum at cap; one unit above cap rejected; no runtime mint path; upgrade cannot inflate supply |
| Amount parsing | 0, 1 base unit, 6 decimals, >6 decimals, negative, huge values, malformed input |
| Fee rewards | Zero fees; no validators; invalid/duplicate validators; rounding; overflow; rewards never exceed collected fees |
| Transactions | Invalid signature; wrong chain ID; replay; wrong sequence; insufficient funds; fee underpayment; duplicate broadcast |
| Staking | Delegate, undelegate, redelegate, unbonding completion, minimum stake, commission bounds |
| Slashing | Downtime, double-sign evidence, jail, tombstone policy, evidence replay |
| Consensus | Four validators; one-third offline; network partition; restart; missed rounds; deterministic app hash |
| Storage | Crash during commit; restore backup; pruning; snapshot/state sync; disk full |
| API | Pagination, malformed requests, rate limits, auth boundaries, stale data indication |
| Wallet | Key import/export safety, signing display, wrong chain ID rejection, recovery tests |
| Explorer | Indexer restart, duplicate events, lag display, block/tx cross-checks |
| Release | Reproducible build, checksums, dependency audit, upgrade rehearsal, rollback rehearsal |

Existing automated tests cover only the helper packages listed in `docs/PROJECT_STATUS.md`. They do not satisfy this matrix.
