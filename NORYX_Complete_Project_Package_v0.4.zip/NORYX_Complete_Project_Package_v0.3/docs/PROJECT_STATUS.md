# NORYX project status

**Status: tested protocol helpers + consolidated engineering specifications. NOT a complete blockchain and NOT mainnet-ready.**

## Confirmed decisions
- Independent Layer-1 project direction
- Proof of Stake consensus direction
- Maximum supply: 100,000,000 NORYX
- Decimals: 6
- Staking rewards only from transaction fees actually collected
- No inflationary issuance
- Intended stack: Cosmos SDK + CometBFT

## Implemented in this package
- Fixed-supply cap arithmetic and allocation validation helper
- Exact decimal-to-base-unit conversion without floating point
- Fee-pool distribution proportional to validator stake
- Deterministic hash-linked block data model and tamper validation (prototype only)
- Automated unit tests for those helper packages
- Consolidated architecture, API/wallet/explorer, security, compatibility, launch-gate and verification specifications

## Not implemented
See `COMPONENT_STATUS.md` for the complete component inventory. In particular, there is no integrated Cosmos SDK app, CometBFT node, production PoS state machine, transaction pipeline, staking/slashing integration, P2P network, persistent state, wallet, explorer, API server, testnet or mainnet.

## Genesis
`genesis.json` is a template with unresolved values. It is not a valid launch genesis. Chain ID, address prefix, allocations, validators, fee policy and consensus parameters require explicit decisions and validation.

## GitHub
A local ZIP is not proof of a GitHub commit. GitHub write access was previously rejected by the integration with HTTP 403; repository changes must be verified by fetching the files/commit after a successful push.
