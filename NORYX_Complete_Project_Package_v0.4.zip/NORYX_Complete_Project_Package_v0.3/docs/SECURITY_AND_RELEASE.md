# Security and release checklist

- [ ] Decide and document chain ID, address prefix and base denomination
- [ ] Finalize genesis allocation table and verify exact total
- [ ] Implement production PoS consensus integration
- [ ] Implement transaction signatures and replay protection
- [ ] Make fee collection and fee distribution atomic
- [ ] Disable all inflation/mint paths and test supply invariants
- [ ] Implement slashing, unbonding and validator-set safety rules
- [ ] Add persistent database, backups and crash recovery
- [ ] Add RPC rate limits, input validation and DoS protections
- [ ] Run multi-validator local testnet and public testnet
- [ ] Fuzz tests, property tests, race tests and independent security audit
- [ ] Publish reproducible binaries, checksums and upgrade procedure
- [ ] Establish monitoring, incident response and validator operations
- [ ] Only then consider mainnet launch

Never publish private validator keys, seed phrases, signing keys or `.env` files.
A public repository must contain no secrets.
