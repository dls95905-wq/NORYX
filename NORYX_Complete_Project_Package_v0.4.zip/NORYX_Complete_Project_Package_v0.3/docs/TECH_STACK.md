# NORYX technology baseline

Status: architecture decision recorded; production application implementation is not yet complete.

## Selected stack
- Cosmos SDK 0.55.x release family
- CometBFT 0.40.x release family
- Go toolchain pinned to the exact version required by the selected SDK release

Use a compatible, tested release set. Do not independently upgrade SDK and CometBFT dependencies. Before implementation, confirm the exact patch versions and Go version against the official release notes and lock them in `go.mod`, CI, and reproducible builds.

## NORYX protocol invariants
- Maximum supply: 100,000,000 NORYX.
- Decimal places: 6; maximum base units: 100,000,000,000,000.
- Runtime inflation and mint-based staking rewards are prohibited.
- Staking rewards may be funded only from transaction fees actually collected by the protocol.
- Fee distribution must be deterministic, bounded by the collected pool, and atomic with state transitions.
- Genesis allocations and network identifiers remain unapproved and must not be invented.

## Required production modules
Auth/accounts, bank, fixed-supply guard, staking, slashing, fee collection/distribution, governance, upgrade handling, and public query/RPC interfaces.

## Implementation acceptance criteria
1. Integrate supply and fee invariants into Cosmos SDK keepers and consensus state transitions; standalone helper functions are insufficient.
2. Disable all inflation and mint paths, including default SDK mint/distribution behavior where applicable.
3. Ensure fees are collected before distribution and that rewards cannot exceed the same block's collected fee pool.
4. Add deterministic integration tests, multi-validator tests, property/fuzz tests, restart/state-recovery tests, and adversarial tests.
5. Run a multi-validator testnet and obtain an independent security review before any public mainnet claim.

This document records the chosen architecture direction. It is not evidence that a production Cosmos SDK application, CometBFT network, wallet, explorer, or public testnet has been implemented.
