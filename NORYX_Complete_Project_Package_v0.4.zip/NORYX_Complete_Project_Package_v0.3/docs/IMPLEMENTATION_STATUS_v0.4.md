# NORYX implementation status — v0.4

## Newly implemented and tested

- `protocol/ledger`: deterministic in-memory ledger execution for Ed25519-signed transfers.
- Chain-ID binding, sender/public-key binding, signature verification, sequence/replay protection, fee accounting, and balance checks.
- Fee distribution from the collected-fee pool only; no minting path exists in the ledger helper.
- Genesis supply-cap and snapshot-integrity checks.

## Still not a running blockchain

The v0.4 package still does not contain a Cosmos SDK application or CometBFT node. It has no persistent database, distributed consensus, staking lifecycle, validator key management, slashing, governance, RPC service, wallet application, explorer/indexer, or deployed testnet. These are not marked complete merely because specifications exist.

## Build status

The standard-library Go packages are expected to pass:

```sh
go test ./...
go vet ./...
python -m json.tool genesis.json
```

The build does not compile or validate Cosmos SDK/CometBFT integration because those dependencies and app wiring are not present.
