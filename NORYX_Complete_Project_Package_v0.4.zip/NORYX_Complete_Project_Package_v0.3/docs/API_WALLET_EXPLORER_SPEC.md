# NORYX API, wallet and explorer specification

This is a product/engineering specification, not an implemented service.

## RPC and API

The public API should expose read-only chain data and authenticated transaction broadcast separately. Suggested endpoints (final paths must match the selected SDK release):

- `GET /health` — node health and sync status
- `GET /status` — chain ID, latest height, block time, catching-up flag
- `GET /blocks/{height}` — block metadata and transactions
- `GET /tx/{hash}` — transaction result and events
- `GET /account/{address}` — account number, sequence and balances
- `GET /validators` — active validator set and voting power
- `GET /staking/delegations/{address}` — delegations and unbondings
- `POST /txs` — broadcast a signed transaction; enforce body limits and rate limits

Never expose validator signing keys, mnemonic phrases, private keys, or unrestricted administrative methods over public RPC.

## Wallet

Minimum release scope:

- Generate/import keys locally using a reviewed Cosmos-compatible key format.
- Display NORYX and base-unit balances without floating-point arithmetic.
- Build and sign transfer/delegation transactions locally.
- Show chain ID, fee, sequence, destination and amount before signing.
- Broadcast signed transactions and track confirmation status.
- Provide recovery guidance without transmitting secrets to a server.

A wallet must not be released until key storage, backup, recovery and transaction-signing flows receive an independent security review.

## Explorer / indexer

Minimum release scope:

- Index blocks, transactions, events, accounts and validator/staking data.
- Use a reorg/finality-aware ingestion process and resume safely after restart.
- Provide pagination, query limits and caching.
- Show source height and indexing lag; never present stale indexer data as live chain state.
- Verify transaction hashes and link explorer records back to node query results.

## Security requirements

Use TLS at public edges, strict CORS, request-size limits, rate limiting, structured audit logs, secret redaction, dependency scanning and monitored uptime. Public explorer queries must not have access to signing or validator-control functions.
