# NORYX implementation roadmap

## Milestone A — Application foundation
- Pin Cosmos SDK / CometBFT compatible versions and Go toolchain.
- Create application wiring, module accounts, store keys, CLI and config.
- Wire auth, bank, staking, slashing, distribution, governance and upgrade modules.
- Add a dedicated fixed-supply guard and disable inflation/mint-based rewards.

## Milestone B — Fee-only rewards
- Define fee collection account and fee denomination.
- Implement deterministic fee pool accounting.
- Route only collected fees to validator/delegator distribution.
- Add invariant checks and adversarial tests for zero fees, rounding, overflow, failed txs and supply cap.

## Milestone C — Node and network
- Build node binary and genesis tooling.
- Configure CometBFT P2P, RPC, state sync, pruning and snapshots.
- Add local multi-validator network scripts and container orchestration.

## Milestone D — User applications
- Wallet-compatible signing and account flows.
- Public API/indexer and block explorer.
- Operator documentation, validator dashboard and monitoring.

## Milestone E — Release readiness
- Unit, integration, property, fuzz, race and upgrade tests.
- Multi-validator public testnet and incident drills.
- Independent security audit and remediation.
- Reproducible release builds, checksums, upgrade and rollback runbooks.
- Mainnet only after external validator operators and infrastructure are ready.

## Honest completion criteria
A source tree or passing unit tests alone is not a launched blockchain. Mainnet readiness requires an executable integrated application, a functioning multi-validator network, operational infrastructure, tested genesis ceremony, and independent security review.
