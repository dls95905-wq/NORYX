# Local development checks

These commands validate only the Go helper packages currently included in this repository.

```sh
go test ./...
go vet ./...
python -m json.tool genesis.json
```

Expected current Go packages:

- `protocol/supply`
- `protocol/fees`
- `protocol/chain`

There is currently no `noryxd` node binary, no `noryx` CLI, no validator command, no RPC server, and no local testnet launcher. Do not attempt to start a network from this package; the required application has not yet been implemented.
