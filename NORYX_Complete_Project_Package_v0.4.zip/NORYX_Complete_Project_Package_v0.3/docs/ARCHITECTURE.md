# NORYX architecture plan

## Target production architecture
A production NORYX network needs a deterministic application state machine
executed by every validator, plus a Byzantine-fault-tolerant consensus and P2P
layer. Cosmos SDK + CometBFT is a candidate architecture, not a final decision.

## Required modules
1. Auth/accounts: addresses, signatures, sequence numbers and replay protection.
2. Bank: balances, transfers, fee deduction and atomic state transitions.
3. Supply: immutable maximum supply of 100,000,000 NORYX; runtime mint disabled.
4. Staking: validator registration, self-delegation, delegation, unbonding.
5. Slashing: double-sign and downtime evidence with bounded penalties.
6. Distribution: rewards only from fees actually collected; no inflation.
7. Governance: parameter changes and software upgrades under defined voting rules.
8. RPC/indexer: public query interface, event indexing and explorer integration.

## Fee-funded rewards
At block execution, fees must first be collected into a protocol-controlled
account. The distribution module may allocate only that exact collected amount.
If no fees are collected, staking rewards for that block are zero. The system
must never mint extra coins to make a target APR.

## Fixed supply
Genesis allocations must sum to no more than 100,000,000 NORYX. If the intended
policy is that the entire supply exists at genesis, allocations must sum to
exactly that amount. The owner has not yet approved allocation recipients.
Runtime inflation must be disabled and tested at the application level.

## Consensus
PoS requires validator power calculation, voting, finality, validator-set
updates, evidence processing and secure genesis coordination. The local block
hash prototype in this package is not consensus.
