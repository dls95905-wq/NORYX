# NORYX deterministic ledger execution prototype

This package adds `protocol/ledger`, a standard-library-only deterministic execution model used for local protocol testing.

## Implemented in this prototype

- Ed25519-signed transfer transactions bound to a chain ID.
- Address derivation from the public key (first 20 bytes of SHA-256, hex encoded).
- Signature verification, account sequence checks, replay rejection, and balance checks.
- Integer-only amounts in 10^-6 NORYX base units.
- Genesis allocation cap of 100,000,000 NORYX / 100,000,000,000,000 base units.
- Transaction fees are deducted from the sender and accumulated in a fee pool.
- Fee-pool distribution is limited to the exact fees collected and uses integer proportional allocation; rounding remainder is assigned deterministically to the lexicographically first validator address.
- Snapshot validation checks supply and hash-linked block integrity.

## Explicitly not implemented

This is not a production state machine. It has no persistence, ABCI interface, CometBFT, mempool, block proposer, peer networking, validator staking state, validator-set updates, slashing, governance, IBC, RPC server, wallet UI, explorer, or multi-node consensus. `DistributeCollectedFees` accepts a stake map from its caller; it does not prove stake ownership or implement staking.

Do not expose this package as a live network, do not use it to custody funds, and do not treat a locally generated block as a consensus-finalized block. The next integration step is to port these invariants into a Cosmos SDK application and test them against the selected supported SDK/CometBFT release family.
