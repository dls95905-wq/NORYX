# Cosmos stack compatibility baseline (checked 2026-11-09)

The official Cosmos documentation lists a 2026.1 release family pairing Cosmos SDK 0.55.x with CometBFT 0.40.x. It also lists the 2025.1 family pairing SDK 0.53.x with CometBFT 0.38.x. A release family is a curated compatibility set; selecting arbitrary latest versions independently is unsafe.

For NORYX implementation:

1. Use the official 2026.1 family as the first candidate for a fresh application.
2. Select exact patch versions from the official release-family documentation and the SDK's own release notes immediately before implementation.
3. Build a minimal application and run its upstream compatibility/integration tests before writing NORYX custom modules.
4. Pin all Go module versions in `go.mod` and commit `go.sum`.
5. Do not depend on a repository `main` branch for production.
6. Re-evaluate the family before any upgrade; never update SDK and CometBFT independently without compatibility verification.

This package deliberately does not add unverified Cosmos dependencies or claim that an SDK application has been built. Official reference: https://github.com/cosmos/docs/blob/main/sdk/latest/release-family.mdx
