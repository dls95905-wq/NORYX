# NORYX — Consolidated Engineering Package v0.4

NORYX is an independent Layer-1 blockchain project with the following approved economic targets:

- Consensus direction: Proof of Stake (PoS)
- Maximum supply: 100,000,000 NORYX
- Decimal places: 6 (100,000,000 base units per NORYX)
- Staking rewards: funded only from transaction fees actually collected
- Inflationary issuance: prohibited
- Intended stack: Cosmos SDK + CometBFT

## Important status notice

**This package is an engineering foundation and specification bundle, NOT a complete or launched blockchain.** It currently contains tested Go protocol helpers for supply-cap validation, fee-pool allocation, and a hash-linked block data model, plus architecture, release, security, and implementation specifications. Version 0.4 also adds a deterministic in-memory ledger test harness for Ed25519-signed transfers, sequence checks, fee collection, and fee-only distribution.

It does not yet contain an integrated Cosmos SDK application, CometBFT node, production PoS state machine, staking/slashing modules, persistent chain database, P2P network, production RPC, wallet, explorer/indexer, or a deployed multi-validator testnet. The new ledger is an in-memory test harness, not a consensus engine or production transaction pipeline. Do not use this package to hold funds or represent NORYX as live.

## Quick checks

Requires Go 1.22+ for the current helper packages:

```sh
go test ./...
go vet ./...
python -m json.tool genesis.json
```

See `docs/IMPLEMENTATION_STATUS_v0.4.md`, `docs/PROTOCOL_STATE_MACHINE.md`, `docs/PROJECT_STATUS.md`, `docs/COMPONENT_STATUS.md`, and `docs/PRODUCTION_BLOCKERS.md` before making any launch claim.

## Repository

https://github.com/dls95905-wq/NORYX

GitHub write access has not yet been verified; a package file existing locally does not mean it has been committed to that repository.
