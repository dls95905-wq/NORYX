// Package chain contains a deterministic hash-linked block data model.
// It is NOT a consensus engine and does not implement networking or PoS voting.
package chain

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
)

var ErrInvalidChain = errors.New("invalid block chain")

type Block struct {
	Height       uint64   `json:"height"`
	PreviousHash string   `json:"previous_hash"`
	Transactions []string `json:"transactions"`
	Hash         string   `json:"hash"`
}

func (b Block) calculatedHash() (string, error) {
	copy := b
	copy.Hash = ""
	raw, err := json.Marshal(copy)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func NewBlock(height uint64, previousHash string, txs []string) (Block, error) {
	b := Block{Height: height, PreviousHash: previousHash, Transactions: append([]string(nil), txs...)}
	h, err := b.calculatedHash()
	if err != nil {
		return Block{}, err
	}
	b.Hash = h
	return b, nil
}

func Validate(blocks []Block) error {
	if len(blocks) == 0 {
		return nil
	}
	for i, b := range blocks {
		if b.Height != uint64(i) {
			return ErrInvalidChain
		}
		if i == 0 && b.PreviousHash != "" {
			return ErrInvalidChain
		}
		if i > 0 && b.PreviousHash != blocks[i-1].Hash {
			return ErrInvalidChain
		}
		h, err := b.calculatedHash()
		if err != nil || h != b.Hash {
			return ErrInvalidChain
		}
	}
	return nil
}
