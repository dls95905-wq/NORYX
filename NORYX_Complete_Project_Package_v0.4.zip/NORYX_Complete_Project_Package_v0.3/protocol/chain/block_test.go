package chain

import "testing"

func TestBlockChainValidation(t *testing.T) {
	g, err := NewBlock(0, "", []string{"genesis"})
	if err != nil {
		t.Fatal(err)
	}
	b, err := NewBlock(1, g.Hash, []string{"tx1"})
	if err != nil {
		t.Fatal(err)
	}
	if err := Validate([]Block{g, b}); err != nil {
		t.Fatal(err)
	}
	b.Transactions[0] = "tampered"
	if err := Validate([]Block{g, b}); err == nil {
		t.Fatal("expected tamper detection")
	}
}
