// Package ledger provides a deterministic, single-process execution model for
// signed NORYX transfers. It is a protocol test harness, NOT an SDK app or
// distributed consensus implementation.
package ledger

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"math/big"
	"sort"
	"sync"
)

const MaxSupply uint64 = 100_000_000_000_000

var (
	ErrChainID   = errors.New("wrong chain id")
	ErrAddress   = errors.New("sender address does not match public key")
	ErrSignature = errors.New("invalid transaction signature")
	ErrNonce     = errors.New("invalid account sequence")
	ErrFunds     = errors.New("insufficient funds")
	ErrAmount    = errors.New("amount and fee must be positive/non-negative as specified")
	ErrSupply    = errors.New("genesis supply exceeds fixed maximum")
	ErrOverflow  = errors.New("balance overflow")
)

type Tx struct {
	ChainID   string `json:"chain_id"`
	From      string `json:"from"`
	To        string `json:"to"`
	Nonce     uint64 `json:"nonce"`
	Amount    uint64 `json:"amount"`
	Fee       uint64 `json:"fee"`
	PublicKey string `json:"public_key"` // hex-encoded Ed25519 public key
	Signature string `json:"signature"`  // hex-encoded Ed25519 signature
}

type signDoc struct {
	ChainID   string `json:"chain_id"`
	From      string `json:"from"`
	To        string `json:"to"`
	Nonce     uint64 `json:"nonce"`
	Amount    uint64 `json:"amount"`
	Fee       uint64 `json:"fee"`
	PublicKey string `json:"public_key"`
}

func Address(pub ed25519.PublicKey) string {
	sum := sha256.Sum256(pub)
	return hex.EncodeToString(sum[:20])
}

func (tx Tx) signBytes() ([]byte, error) {
	d := signDoc{tx.ChainID, tx.From, tx.To, tx.Nonce, tx.Amount, tx.Fee, tx.PublicKey}
	return json.Marshal(d)
}

func Sign(chainID, to string, nonce, amount, fee uint64, privateKey ed25519.PrivateKey) (Tx, error) {
	if len(privateKey) != ed25519.PrivateKeySize {
		return Tx{}, errors.New("invalid Ed25519 private key")
	}
	pub := privateKey.Public().(ed25519.PublicKey)
	tx := Tx{ChainID: chainID, From: Address(pub), To: to, Nonce: nonce, Amount: amount, Fee: fee, PublicKey: hex.EncodeToString(pub)}
	b, err := tx.signBytes()
	if err != nil {
		return Tx{}, err
	}
	tx.Signature = hex.EncodeToString(ed25519.Sign(privateKey, b))
	return tx, nil
}

type Block struct {
	Height       uint64 `json:"height"`
	PreviousHash string `json:"previous_hash"`
	Transactions []Tx   `json:"transactions"`
	Hash         string `json:"hash"`
}

type Snapshot struct {
	ChainID       string            `json:"chain_id"`
	Balances      map[string]uint64 `json:"balances"`
	Nonces        map[string]uint64 `json:"nonces"`
	CollectedFees uint64            `json:"collected_fees"`
	Blocks        []Block           `json:"blocks"`
}

type Ledger struct {
	mu sync.RWMutex
	s  Snapshot
}

func New(chainID string, allocations map[string]uint64) (*Ledger, error) {
	if chainID == "" {
		return nil, errors.New("chain id is required")
	}
	balances := make(map[string]uint64, len(allocations))
	var total uint64
	for a, v := range allocations {
		if a == "" {
			return nil, errors.New("empty genesis address")
		}
		if math.MaxUint64-total < v {
			return nil, ErrOverflow
		}
		total += v
		balances[a] = v
	}
	if total > MaxSupply {
		return nil, ErrSupply
	}
	l := &Ledger{s: Snapshot{ChainID: chainID, Balances: balances, Nonces: map[string]uint64{}}}
	g := Block{Height: 0, Transactions: []Tx{}}
	h, err := blockHash(g)
	if err != nil {
		return nil, err
	}
	g.Hash = h
	l.s.Blocks = []Block{g}
	return l, nil
}

func blockHash(b Block) (string, error) {
	b.Hash = ""
	raw, err := json.Marshal(b)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(raw)
	return hex.EncodeToString(h[:]), nil
}

func (l *Ledger) Apply(tx Tx) (Block, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if tx.ChainID != l.s.ChainID {
		return Block{}, ErrChainID
	}
	pubBytes, err := hex.DecodeString(tx.PublicKey)
	if err != nil || len(pubBytes) != ed25519.PublicKeySize {
		return Block{}, ErrAddress
	}
	pub := ed25519.PublicKey(pubBytes)
	if Address(pub) != tx.From {
		return Block{}, ErrAddress
	}
	sig, err := hex.DecodeString(tx.Signature)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return Block{}, ErrSignature
	}
	raw, err := tx.signBytes()
	if err != nil || !ed25519.Verify(pub, raw, sig) {
		return Block{}, ErrSignature
	}
	if tx.To == "" || tx.To == tx.From || tx.Amount == 0 {
		return Block{}, ErrAmount
	}
	if tx.Nonce != l.s.Nonces[tx.From] {
		return Block{}, ErrNonce
	}
	if math.MaxUint64-tx.Amount < tx.Fee {
		return Block{}, ErrOverflow
	}
	cost := tx.Amount + tx.Fee
	if l.s.Balances[tx.From] < cost {
		return Block{}, ErrFunds
	}
	if math.MaxUint64-l.s.Balances[tx.To] < tx.Amount || math.MaxUint64-l.s.CollectedFees < tx.Fee {
		return Block{}, ErrOverflow
	}
	l.s.Balances[tx.From] -= cost
	l.s.Balances[tx.To] += tx.Amount
	l.s.CollectedFees += tx.Fee
	l.s.Nonces[tx.From]++
	prev := l.s.Blocks[len(l.s.Blocks)-1]
	b := Block{Height: prev.Height + 1, PreviousHash: prev.Hash, Transactions: []Tx{tx}}
	b.Hash, err = blockHash(b)
	if err != nil {
		return Block{}, err
	}
	l.s.Blocks = append(l.s.Blocks, b)
	return b, nil
}

// DistributeCollectedFees pays the current fee pool to validator addresses in
// proportion to stake. The pool is cleared only after a successful allocation.
// This is a deterministic test-harness operation, not a staking module.
func (l *Ledger) DistributeCollectedFees(stakes map[string]uint64) (map[string]uint64, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if len(stakes) == 0 {
		if l.s.CollectedFees == 0 {
			return map[string]uint64{}, nil
		}
		return nil, errors.New("no validators")
	}
	keys := make([]string, 0, len(stakes))
	var total uint64
	for k, v := range stakes {
		if k == "" || v == 0 {
			return nil, errors.New("validator and positive stake required")
		}
		if math.MaxUint64-total < v {
			return nil, ErrOverflow
		}
		total += v
		keys = append(keys, k)
	}
	sort.Strings(keys)
	pool := l.s.CollectedFees
	shares := make(map[string]uint64, len(keys))
	var allocated uint64
	// big.Int keeps proportional calculations exact for the full uint64 range.
	p := new(big.Int).SetUint64(pool)
	t := new(big.Int).SetUint64(total)
	for _, k := range keys {
		n := new(big.Int).SetUint64(stakes[k])
		n.Mul(n, p)
		n.Div(n, t)
		v := n.Uint64()
		shares[k] = v
		allocated += v
	}
	shares[keys[0]] += pool - allocated
	for k, v := range shares {
		if math.MaxUint64-l.s.Balances[k] < v {
			return nil, ErrOverflow
		}
	}
	for k, v := range shares {
		l.s.Balances[k] += v
	}
	l.s.CollectedFees = 0
	return shares, nil
}

func (l *Ledger) Snapshot() Snapshot {
	l.mu.RLock()
	defer l.mu.RUnlock()
	out := Snapshot{ChainID: l.s.ChainID, Balances: map[string]uint64{}, Nonces: map[string]uint64{}, CollectedFees: l.s.CollectedFees, Blocks: make([]Block, len(l.s.Blocks))}
	for i, b := range l.s.Blocks {
		out.Blocks[i] = b
		out.Blocks[i].Transactions = make([]Tx, len(b.Transactions))
		copy(out.Blocks[i].Transactions, b.Transactions)
	}
	for k, v := range l.s.Balances {
		out.Balances[k] = v
	}
	for k, v := range l.s.Nonces {
		out.Nonces[k] = v
	}
	return out
}

func ValidateSnapshot(s Snapshot) error {
	if s.ChainID == "" || len(s.Blocks) == 0 {
		return errors.New("invalid snapshot")
	}
	var total uint64
	for _, v := range s.Balances {
		if math.MaxUint64-total < v {
			return ErrOverflow
		}
		total += v
	}
	if math.MaxUint64-total < s.CollectedFees {
		return ErrOverflow
	}
	total += s.CollectedFees
	if total > MaxSupply {
		return ErrSupply
	}
	for i, b := range s.Blocks {
		if b.Height != uint64(i) {
			return fmt.Errorf("block height mismatch")
		}
		if i > 0 && b.PreviousHash != s.Blocks[i-1].Hash {
			return errors.New("broken block link")
		}
		h, e := blockHash(b)
		if e != nil || h != b.Hash {
			return errors.New("invalid block hash")
		}
	}
	return nil
}
