package ledger

import (
	"crypto/ed25519"
	"crypto/rand"
	"testing"
)

func TestSignedTransferAndFeeOnlyDistribution(t *testing.T) {
	pubA, privA, _ := ed25519.GenerateKey(rand.Reader)
	pubB, _, _ := ed25519.GenerateKey(rand.Reader)
	pubV, _, _ := ed25519.GenerateKey(rand.Reader)
	a, b, v := Address(pubA), Address(pubB), Address(pubV)
	l, err := New("noryx-test-1", map[string]uint64{a: 1_000, b: 0, v: 0})
	if err != nil {
		t.Fatal(err)
	}
	tx, err := Sign("noryx-test-1", b, 0, 250, 10, privA)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = l.Apply(tx); err != nil {
		t.Fatal(err)
	}
	s := l.Snapshot()
	if s.Balances[a] != 740 || s.Balances[b] != 250 || s.CollectedFees != 10 {
		t.Fatalf("unexpected state: %+v", s)
	}
	got, err := l.DistributeCollectedFees(map[string]uint64{v: 100})
	if err != nil {
		t.Fatal(err)
	}
	if got[v] != 10 {
		t.Fatalf("expected only collected 10 fee units, got %d", got[v])
	}
	s = l.Snapshot()
	if s.Balances[v] != 10 || s.CollectedFees != 0 {
		t.Fatal("fee pool was not paid and cleared")
	}
	if err := ValidateSnapshot(s); err != nil {
		t.Fatal(err)
	}
}

func TestRejectTamperedAndReplay(t *testing.T) {
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	recipient, _, _ := ed25519.GenerateKey(rand.Reader)
	from, to := Address(pub), Address(recipient)
	l, _ := New("noryx-test-1", map[string]uint64{from: 500})
	tx, _ := Sign("noryx-test-1", to, 0, 100, 1, priv)
	tampered := tx
	tampered.Amount = 101
	if _, err := l.Apply(tampered); err != ErrSignature {
		t.Fatalf("expected signature error, got %v", err)
	}
	if _, err := l.Apply(tx); err != nil {
		t.Fatal(err)
	}
	if _, err := l.Apply(tx); err != ErrNonce {
		t.Fatalf("expected replay rejection, got %v", err)
	}
}

func TestGenesisSupplyCap(t *testing.T) {
	if _, err := New("noryx-test-1", map[string]uint64{"a": MaxSupply + 1}); err != ErrSupply {
		t.Fatalf("expected cap error, got %v", err)
	}
}
