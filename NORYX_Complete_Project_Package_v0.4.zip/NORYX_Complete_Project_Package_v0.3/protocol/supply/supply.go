// Package supply enforces NORYX's fixed maximum supply.
package supply

import (
	"errors"
	"fmt"
	"math"
	"math/big"
)

const (
	Decimals uint32 = 6
	MaxCoins uint64 = 100_000_000
)

var (
	ErrNegativeAmount = errors.New("amount must not be negative")
	ErrSupplyExceeded = errors.New("maximum NORYX supply exceeded")
)

// MaxBaseUnits returns a fresh integer so callers cannot mutate the protocol cap.
func MaxBaseUnits() *big.Int {
	factor := new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(Decimals)), nil)
	return new(big.Int).Mul(new(big.Int).SetUint64(MaxCoins), factor)
}

// State records the total supply established at genesis. There is deliberately
// no runtime mint/issue method: the project policy has no inflation.
type State struct{ issued *big.Int }

// NewFromGenesis validates the allocation list and creates the immutable supply
// snapshot. Balances and transfers belong in the bank module, not this helper.
func NewFromGenesis(allocations []*big.Int) (*State, error) {
	if err := ValidateAllocations(allocations); err != nil {
		return nil, err
	}
	total := new(big.Int)
	for _, a := range allocations {
		total.Add(total, a)
	}
	return &State{issued: total}, nil
}

func (s *State) Issued() *big.Int    { return new(big.Int).Set(s.issued) }
func (s *State) Remaining() *big.Int { return new(big.Int).Sub(MaxBaseUnits(), s.issued) }

// ValidateAllocations checks that all non-negative genesis allocations fit the cap.
func ValidateAllocations(allocations []*big.Int) error {
	total := new(big.Int)
	for _, a := range allocations {
		if a == nil || a.Sign() < 0 {
			return ErrNegativeAmount
		}
		total.Add(total, a)
		if total.Cmp(MaxBaseUnits()) > 0 {
			return ErrSupplyExceeded
		}
	}
	return nil
}

// ParseCoinsToBaseUnits parses a decimal NORYX amount without floating point.
func ParseCoinsToBaseUnits(value string) (*big.Int, error) {
	if value == "" {
		return nil, fmt.Errorf("empty amount")
	}
	r, ok := new(big.Rat).SetString(value)
	if !ok || r.Sign() < 0 {
		return nil, ErrNegativeAmount
	}
	scaled := new(big.Rat).Mul(r, new(big.Rat).SetInt(new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(Decimals)), nil)))
	if !scaled.IsInt() {
		return nil, fmt.Errorf("too many decimal places")
	}
	return new(big.Int).Set(scaled.Num()), nil
}

// SafeAddUint64 is provided for bounded counters that must reject overflow.
func SafeAddUint64(a, b uint64) (uint64, error) {
	if math.MaxUint64-a < b {
		return 0, fmt.Errorf("integer overflow")
	}
	return a + b, nil
}
