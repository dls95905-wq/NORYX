package supply

import (
	"math/big"
	"testing"
)

func TestGenesisSupplyCap(t *testing.T) {
	cap := MaxBaseUnits()
	s, err := NewFromGenesis([]*big.Int{cap})
	if err != nil {
		t.Fatal(err)
	}
	if s.Issued().Cmp(cap) != 0 {
		t.Fatal("genesis supply mismatch")
	}
	if s.Remaining().Sign() != 0 {
		t.Fatal("expected zero remaining supply")
	}
	cap.SetInt64(1) // Mutating caller copy must not mutate protocol constant/state.
	if MaxBaseUnits().String() != "100000000000000" {
		t.Fatal("protocol cap was mutated")
	}
}
func TestParseCoins(t *testing.T) {
	got, err := ParseCoinsToBaseUnits("12.345678")
	if err != nil {
		t.Fatal(err)
	}
	if got.String() != "12345678" {
		t.Fatalf("got %s", got)
	}
	if _, err := ParseCoinsToBaseUnits("0.0000001"); err == nil {
		t.Fatal("expected precision error")
	}
}
func TestAllocations(t *testing.T) {
	if err := ValidateAllocations([]*big.Int{big.NewInt(10), big.NewInt(20)}); err != nil {
		t.Fatal(err)
	}
	if err := ValidateAllocations([]*big.Int{MaxBaseUnits(), big.NewInt(1)}); err != ErrSupplyExceeded {
		t.Fatalf("got %v", err)
	}
}
