package fees

import (
	"math/big"
	"testing"
)

func TestDistributionNeverExceedsFees(t *testing.T) {
	pool := big.NewInt(101)
	got, err := Distribute(pool, []ValidatorStake{{"valA", big.NewInt(1)}, {"valB", big.NewInt(2)}})
	if err != nil {
		t.Fatal(err)
	}
	sum := new(big.Int).Add(got["valA"], got["valB"])
	if sum.Cmp(pool) != 0 {
		t.Fatalf("distributed %s, collected %s", sum, pool)
	}
}
func TestRejectInvalidStake(t *testing.T) {
	_, err := Distribute(big.NewInt(5), []ValidatorStake{{"bad", big.NewInt(0)}})
	if err == nil {
		t.Fatal("expected invalid stake error")
	}
}
func TestNoValidatorCannotReceiveFees(t *testing.T) {
	_, err := Distribute(big.NewInt(1), nil)
	if err == nil {
		t.Fatal("expected error")
	}
}
