// Package fees distributes only fees already collected by the protocol.
package fees

import (
	"errors"
	"math/big"
)

var ErrInvalidStake = errors.New("stake must be positive")

type ValidatorStake struct {
	Validator string
	Stake     *big.Int
}

// Distribute allocates the entire collected fee pool proportionally to stake.
// Integer-division remainder is assigned deterministically to the first validator
// in the supplied order. No new NORYX is created by this function.
func Distribute(collected *big.Int, validators []ValidatorStake) (map[string]*big.Int, error) {
	if collected == nil || collected.Sign() < 0 {
		return nil, errors.New("collected fees must be non-negative")
	}
	out := make(map[string]*big.Int, len(validators))
	total := new(big.Int)
	for _, v := range validators {
		if v.Validator == "" || v.Stake == nil || v.Stake.Sign() <= 0 {
			return nil, ErrInvalidStake
		}
		if _, exists := out[v.Validator]; exists {
			return nil, errors.New("duplicate validator")
		}
		total.Add(total, v.Stake)
		out[v.Validator] = new(big.Int)
	}
	if len(validators) == 0 {
		if collected.Sign() == 0 {
			return out, nil
		}
		return nil, errors.New("cannot distribute fees without validators")
	}
	allocated := new(big.Int)
	for _, v := range validators {
		share := new(big.Int).Mul(collected, v.Stake)
		share.Quo(share, total)
		out[v.Validator] = share
		allocated.Add(allocated, share)
	}
	remainder := new(big.Int).Sub(collected, allocated)
	out[validators[0].Validator].Add(out[validators[0].Validator], remainder)
	return out, nil
}
