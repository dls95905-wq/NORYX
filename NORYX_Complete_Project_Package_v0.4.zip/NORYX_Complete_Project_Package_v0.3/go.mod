module github.com/dls95905-wq/NORYX

go 1.22
